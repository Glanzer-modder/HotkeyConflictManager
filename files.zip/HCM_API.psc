; ============================================================
;  HCM_API.psc  -  Hotkey Conflict Manager native API stub
; ============================================================

Scriptname HCM_API Hidden

; Cross-mod conflict check - returns the conflicting plugin name, or "" if the key is free.
; Pass 'self' as akCaller so the caller's own registration is excluded from the check.
string Function CheckKeyConflict(int aiKeyCode, Form akCaller) global native

; Mod Keys display — call GetAssignedKeyCount first to rebuild the mod cache,
; then iterate 0..count-1 with the three display functions.
; Status: 0=normal  1=mod conflict(red)  2=orphan(orange)
;         3=game conflict(red)  4=mod+game conflict(red)
int    Function GetAssignedKeyCount()               global native
string Function GetKeyDisplayLeft  (int aiIndex)    global native
string Function GetKeyDisplayRight (int aiIndex)    global native
int    Function GetKeyDisplayStatus(int aiIndex)    global native
int    Function GetModConflictCount()               global native
int    Function GetGameConflictCount()              global native

; Game Keys display — call GetGameKeyCount first to rebuild the game cache,
; then iterate 0..count-1 with the three display functions.
; Status: 0=no mod conflict  1=mod conflict(red)
int    Function GetGameKeyCount()                       global native
string Function GetGameKeyDisplayLeft  (int aiIndex)    global native
string Function GetGameKeyDisplayRight (int aiIndex)    global native
int    Function GetGameKeyDisplayStatus(int aiIndex)    global native

; Unused Keys display — call GetUnusedKeyCount first to rebuild the cache,
; then use the section counts to iterate each category using combined indices:
;   keyboard entries: 0 .. GetUnusedKeyboardCount()-1
;   mouse entries:    GetUnusedKeyboardCount() .. +GetUnusedMouseCount()-1
;   controller:       GetUnusedKeyboardCount()+GetUnusedMouseCount() .. total-1
int    Function GetUnusedKeyCount()          global native
int    Function GetUnusedKeyboardCount()     global native
int    Function GetUnusedMouseCount()        global native
int    Function GetUnusedControllerCount()   global native
string Function GetUnusedKeyDisplayLeft(int aiIndex) global native

; Key display keyCode accessors — returns the raw DX scan code for each display
; entry so the MCM can detect category changes and insert section headers.
int Function GetKeyDisplayKeyCode    (int aiIndex) global native
int Function GetGameKeyDisplayKeyCode(int aiIndex) global native

; Mod Keys entry removal
string Function GetKeyDisplayPlugin(int aiIndex)         global native
Function       RemoveEntry(int aiKeyCode, string asPlugin) global native

; Configuration page
Function SetPopupWarningsEnabled(bool abEnabled)          global native
Function SetGameConflictWarningsEnabled(bool abEnabled)    global native
Function ClearOrphans()                          global native
Function ClearRegistry()                         global native
Function SetDebugModeEnabled(bool abEnabled)     global native
