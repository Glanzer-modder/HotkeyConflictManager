; ============================================================
;  HCM_MCM.psc  -  Hotkey Conflict Manager MCM
; ============================================================

Scriptname HCM_MCM extends SKI_ConfigBase

; ---------------------------------------------------------------------------
; Properties
; ---------------------------------------------------------------------------

GlobalVariable Property glz_HCM_warnings       Auto
GlobalVariable Property glz_HCM_debug          Auto
GlobalVariable Property glz_HCM_game_warnings  Auto
bool           Property bDebugMode = false Auto
int[]          Property iModKeyOptionIDs Auto   ; option IDs for Mod Keys entries (set during OnPageReset)
int            Property iModKeyCount = 0 Auto   ; how many entries are tracked this render (max 128)

; ---------------------------------------------------------------------------
; MCM setup
; ---------------------------------------------------------------------------

Event OnConfigInit()
    ModName  = "Hotkey Conflict Manager"
    Pages    = new string[4]
    Pages[0] = "Mod Keys"
    Pages[1] = "Game Keys"
    Pages[2] = "Unused Keys"
    Pages[3] = "Configuration"

    ; Sync toggle states with saved global variable values
    if glz_HCM_warnings
        HCM_API.SetPopupWarningsEnabled(glz_HCM_warnings.GetValue() as bool)
    endif
    if glz_HCM_debug
        HCM_API.SetDebugModeEnabled(glz_HCM_debug.GetValue() as bool)
    endif
    if glz_HCM_game_warnings
        HCM_API.SetGameConflictWarningsEnabled(glz_HCM_game_warnings.GetValue() as bool)
    endif
EndEvent

; ---------------------------------------------------------------------------
; Page display
; ---------------------------------------------------------------------------

Event OnPageReset(string a_page)

    if a_page == ""
        LoadCustomContent("HotkeyConflictManager/logo.dds")
        return
    else
        UnloadCustomContent()
    endif

    if a_page == "Mod Keys"

        ; Both caches must be built before we read any counts.
        ; GetAssignedKeyCount rebuilds the mod cache (and _gameConflictCount).
        ; GetGameKeyCount rebuilds the game cache (and refines _gameConflictCount).
        int count        = HCM_API.GetAssignedKeyCount()
        int gameKeyCount = HCM_API.GetGameKeyCount()
        int modConflicts  = HCM_API.GetModConflictCount()
        int gameConflicts = HCM_API.GetGameConflictCount()

        SetCursorFillMode(LEFT_TO_RIGHT)

        ; --- Header row: conflict summary ---
        if modConflicts > 0 || gameConflicts > 0
            string sHeader = ""

            if modConflicts > 0
                string sWord = " mod conflict"
                if modConflicts != 1
                    sWord = " mod conflicts"
                endif
                sHeader = modConflicts + sWord
            endif

            if gameConflicts > 0
                if modConflicts > 0
                    sHeader = sHeader + ", "
                endif
                string sWord = " game conflict"
                if gameConflicts != 1
                    sWord = " game conflicts"
                endif
                sHeader = sHeader + gameConflicts + sWord
            endif

            AddTextOption("<font color='#800000'>" + sHeader + " detected</font>", "")
        else
            AddTextOption("No conflicts detected", "")
        endif
        AddEmptyOption()

        ; --- Scan code info row ---
        if count > 0
            AddTextOptionST("ScanCodeInfo", "Numbers in brackets are DX scan codes.", "")
            AddEmptyOption()
        endif

        ; --- Key entries: one row per (keyCode, plugin) pair ---
        if count == 0
            AddTextOption("No keys registered yet.", "")
            AddEmptyOption()
            iModKeyCount = 0
        else
            ; Allocate option ID tracking array (max 128 entries per Papyrus limit)
            iModKeyOptionIDs = new int[128]
            iModKeyCount = count
            if iModKeyCount > 128
                iModKeyCount = 128
            endif

            int lastCategory = -1  ; -1 = not yet set; 0=keyboard 1=mouse 2=controller

            int i = 0
            while i < count
                string sLeft    = HCM_API.GetKeyDisplayLeft(i)
                string sRight   = HCM_API.GetKeyDisplayRight(i)
                int    iStatus  = HCM_API.GetKeyDisplayStatus(i)
                int    iKeyCode = HCM_API.GetKeyDisplayKeyCode(i)

                ; Determine category from keyCode
                int category = 0
                if iKeyCode >= 266
                    category = 2
                elseif iKeyCode >= 256
                    category = 1
                endif

                ; Insert section header when category changes
                if category != lastCategory
                    if category == 0
                        AddHeaderOption("Keyboard")
                    elseif category == 1
                        AddHeaderOption("Mouse")
                    else
                        AddHeaderOption("Controller")
                    endif
                    AddEmptyOption()  ; complete header row
                    lastCategory = category
                endif

                ; Store the left-column option ID for click handling (up to array limit).
                ; The right column badge is disabled so only the left column is clickable.
                if iStatus == 2
                    ; Orphan - orange
                    if i < 128
                        iModKeyOptionIDs[i] = AddTextOption("<font color='#FF6600'>" + sLeft  + "</font>", "")
                    else
                        AddTextOption("<font color='#FF6600'>" + sLeft  + "</font>", "")
                    endif
                    AddTextOption("<font color='#FF6600'>" + sRight + "</font>", "", OPTION_FLAG_DISABLED)
                elseif iStatus > 0
                    ; Any conflict type (1=MOD, 3=GAME, 4=MOD+GAME) - dark red
                    if i < 128
                        iModKeyOptionIDs[i] = AddTextOption("<font color='#800000'>" + sLeft  + "</font>", "")
                    else
                        AddTextOption("<font color='#800000'>" + sLeft  + "</font>", "")
                    endif
                    AddTextOption("<font color='#800000'>" + sRight + "</font>", "", OPTION_FLAG_DISABLED)
                else
                    ; Normal - plain text, empty right column
                    if i < 128
                        iModKeyOptionIDs[i] = AddTextOption(sLeft, "")
                    else
                        AddTextOption(sLeft, "")
                    endif
                    AddEmptyOption()
                endif
                i += 1
            endwhile
        endif

    elseif a_page == "Game Keys"

        ; Rebuild game cache to get fresh counts and display data
        int gameCount     = HCM_API.GetGameKeyCount()
        int gameConflicts = HCM_API.GetGameConflictCount()

        SetCursorFillMode(LEFT_TO_RIGHT)

        ; --- Header row ---
        if gameConflicts > 0
            string sWord = " game key conflict"
            if gameConflicts != 1
                sWord = " game key conflicts"
            endif
            AddTextOption("<font color='#800000'>" + gameConflicts + sWord + " with mods</font>", "")
        else
            AddTextOption("No game key conflicts with mods", "")
        endif
        AddEmptyOption()

        ; --- Scan code info row ---
        if gameCount > 0
            AddTextOptionST("ScanCodeInfo", "Numbers in brackets are DX scan codes.", "")
            AddEmptyOption()
        endif

        ; --- Game key entries ---
        if gameCount == 0
            AddTextOption("No game keys found.", "")
            AddEmptyOption()
        else
            int lastCategory = -1  ; -1 = not yet set; 0=keyboard 1=mouse 2=controller

            int i = 0
            while i < gameCount
                string sLeft    = HCM_API.GetGameKeyDisplayLeft(i)
                string sRight   = HCM_API.GetGameKeyDisplayRight(i)
                int    iStatus  = HCM_API.GetGameKeyDisplayStatus(i)
                int    iKeyCode = HCM_API.GetGameKeyDisplayKeyCode(i)

                ; Determine category from keyCode
                int category = 0
                if iKeyCode >= 266
                    category = 2
                elseif iKeyCode >= 256
                    category = 1
                endif

                ; Insert section header when category changes
                if category != lastCategory
                    if category == 0
                        AddHeaderOption("Keyboard")
                    elseif category == 1
                        AddHeaderOption("Mouse")
                    else
                        AddHeaderOption("Controller")
                    endif
                    AddEmptyOption()  ; complete header row
                    lastCategory = category
                endif

                if iStatus == 1
                    ; Mod conflict - dark red on both columns
                    AddTextOption("<font color='#800000'>" + sLeft  + "</font>", "")
                    AddTextOption("<font color='#800000'>" + sRight + "</font>", "")
                else
                    ; Normal game key - plain text, empty right column
                    AddTextOption(sLeft, "")
                    AddEmptyOption()
                endif
                i += 1
            endwhile
        endif

    elseif a_page == "Unused Keys"

        ; Rebuild unused key cache (keyboard/mouse/controller together)
        int unusedTotal = HCM_API.GetUnusedKeyCount()
        int kbCount     = HCM_API.GetUnusedKeyboardCount()
        int moCount     = HCM_API.GetUnusedMouseCount()
        int ctCount     = HCM_API.GetUnusedControllerCount()

        SetCursorFillMode(LEFT_TO_RIGHT)

        ; --- Page summary ---
        if unusedTotal == 0
            AddTextOption("All known keys are assigned to mods or game actions.", "")
        else
            AddTextOption(unusedTotal + " unassigned keys available.", "")
        endif
        AddEmptyOption()

        ; -------------------------------------------------------
        ; Keyboard section
        ; -------------------------------------------------------
        AddHeaderOption("Keyboard")
        AddEmptyOption()  ; complete header row
        if kbCount == 0
            AddTextOption("No unassigned keyboard keys.", "")
            AddEmptyOption()
        else
            int i = 0
            while i < kbCount
                AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i), "")
                if i + 1 < kbCount
                    AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i + 1), "")
                else
                    AddEmptyOption()
                endif
                i += 2
            endwhile
        endif
        AddEmptyOption()
        AddEmptyOption()

        ; -------------------------------------------------------
        ; Mouse section
        ; -------------------------------------------------------
        AddHeaderOption("Mouse")
        AddEmptyOption()  ; complete header row
        if moCount == 0
            AddTextOption("No unassigned mouse buttons.", "")
            AddEmptyOption()
        else
            int moStart = kbCount
            int i = moStart
            while i < moStart + moCount
                AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i), "")
                if i + 1 < moStart + moCount
                    AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i + 1), "")
                else
                    AddEmptyOption()
                endif
                i += 2
            endwhile
        endif
        AddEmptyOption()
        AddEmptyOption()

        ; -------------------------------------------------------
        ; Controller section
        ; -------------------------------------------------------
        AddHeaderOption("Controller")
        AddEmptyOption()  ; complete header row
        if ctCount == 0
            AddTextOption("No unassigned controller buttons.", "")
            AddEmptyOption()
        else
            int ctStart = kbCount + moCount
            int i = ctStart
            while i < ctStart + ctCount
                AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i), "")
                if i + 1 < ctStart + ctCount
                    AddTextOption(HCM_API.GetUnusedKeyDisplayLeft(i + 1), "")
                else
                    AddEmptyOption()
                endif
                i += 2
            endwhile
        endif

    elseif a_page == "Configuration"

        SetCursorFillMode(TOP_TO_BOTTOM)
        AddHeaderOption("Popup Warnings")
        bool bEnabled = true
        if glz_HCM_warnings
            bEnabled = glz_HCM_warnings.GetValue() as bool
        endif
        AddToggleOptionST("PopupWarningsState", "Warnings for Mod Key Conflicts", bEnabled)

        bool bGameEnabled = true
        if glz_HCM_game_warnings
            bGameEnabled = glz_HCM_game_warnings.GetValue() as bool
        endif
        AddToggleOptionST("GameConflictWarningsState", "Warnings for Game Key Conflicts", bGameEnabled)

        AddEmptyOption()
        AddHeaderOption("Debug")
        AddToggleOptionST("DebugModeState", "Debug Mode", bDebugMode)

        AddEmptyOption()
        AddHeaderOption("Registry Management")
        AddTextOptionST("ClearOrphansState",  "Clear Orphaned Registry Entries", "")
        AddTextOptionST("ClearRegistryState", "Clear ALL Registry Entries (CAUTION!)", "")

    endif

EndEvent

; ---------------------------------------------------------------------------
; Scan code info hover state (shared by both Mod Keys and Game Keys pages)
; ---------------------------------------------------------------------------

State ScanCodeInfo
    Event OnHighlightST()
        SetInfoText("The number in brackets is the DirectX keyboard scan code for the standard US keyboard layout.")
    EndEvent
EndState

; ---------------------------------------------------------------------------
; Configuration states
; ---------------------------------------------------------------------------

State PopupWarningsState

    Event OnSelectST()
        bool bCurrent = true
        if glz_HCM_warnings
            bCurrent = glz_HCM_warnings.GetValue() as bool
        endif
        bool bNew = !bCurrent
        if glz_HCM_warnings
            glz_HCM_warnings.SetValue(bNew as float)
        endif
        HCM_API.SetPopupWarningsEnabled(bNew)
        SetToggleOptionValueST(bNew)
    EndEvent

    Event OnHighlightST()
        SetInfoText("Controls popup warnings when a mod registers a key already used by another mod during normal gameplay. When the Journal Menu is open, conflicts are always shown regardless of this setting.")
    EndEvent

EndState

State GameConflictWarningsState

    Event OnSelectST()
        bool bCurrent = true
        if glz_HCM_game_warnings
            bCurrent = glz_HCM_game_warnings.GetValue() as bool
        endif
        bool bNew = !bCurrent
        if glz_HCM_game_warnings
            glz_HCM_game_warnings.SetValue(bNew as float)
        endif
        HCM_API.SetGameConflictWarningsEnabled(bNew)
        SetToggleOptionValueST(bNew)
    EndEvent

    Event OnHighlightST()
        SetInfoText("Controls popup warnings when a mod registers a key already bound to a game action (e.g. Map, Journal) during normal gameplay. When the Journal Menu is open, conflicts are always shown regardless of this setting.")
    EndEvent

EndState

State DebugModeState

    Event OnSelectST()
        bDebugMode = !bDebugMode
        if glz_HCM_debug
            glz_HCM_debug.SetValue(bDebugMode as float)
        endif
        HCM_API.SetDebugModeEnabled(bDebugMode)
        SetToggleOptionValueST(bDebugMode)
    EndEvent

    Event OnHighlightST()
        SetInfoText("Turning on debug will cause a message in the upper left to appear every time a key gets registered or unregistered. To read messages that have scrolled off, you can use Advanced Notification Log NG (https://www.nexusmods.com/skyrimspecialedition/mods/67975)")
    EndEvent

EndState

State ClearRegistryState

    Event OnSelectST()
        bool bConfirm = ShowMessage( \
            "This will clear ALL registry entries. Hotkey conflicts " + \
            "will not be detected until mods re-register their keys " + \
            "or you manually re-register them yourself. ARE YOU SURE?", \
            true, "$Yes", "$No")
        if bConfirm
            HCM_API.ClearRegistry()
            ForcePageReset()
        endif
    EndEvent

    Event OnHighlightST()
        SetInfoText("CAUTION! Removes all entries from the hotkey registry. Keys will need to be re-registered to repopulate it.")
    EndEvent

EndState

State ClearOrphansState

    Event OnSelectST()
        bool bConfirm = ShowMessage( \
            "Remove all orphaned registry entries? These are entries " + \
            "from plugins that are no longer in your load order.", \
            true, "$Yes", "$No")
        if bConfirm
            HCM_API.ClearOrphans()
            ForcePageReset()
        endif
    EndEvent

    Event OnHighlightST()
        SetInfoText("Removes entries for plugins that are no longer in your load order. Active registrations are not affected.")
    EndEvent

EndState

; ---------------------------------------------------------------------------
; Registration lifecycle
; ---------------------------------------------------------------------------

; OnInit() is not needed since the parent's implementation runs
; automatically when OnInit() is missing, but I'm leaving it here
; in case I need to add something to it later and I'll never
; remember to add Parent.OnInit() to it which causes the MCM to
; never register!
;Event OnInit()
;    Parent.OnInit()
;EndEvent

Event OnOptionSelect(int a_option)
    ; Handle clicks on Mod Keys entries - offer to remove the entry from the registry
    int i = 0
    while i < iModKeyCount
        if a_option == iModKeyOptionIDs[i]
            int    iKeyCode = HCM_API.GetKeyDisplayKeyCode(i)
            string sPlugin  = HCM_API.GetKeyDisplayPlugin(i)
            string sLeft    = HCM_API.GetKeyDisplayLeft(i)

            bool bConfirm = ShowMessage(                 "Remove this entry from the registry?

" +                 sLeft + "

" +                 "The mod itself is not affected. The entry will reappear " +                 "automatically if the mod re-registers this key.",                 true, "$Yes", "$No")

            if bConfirm
                HCM_API.RemoveEntry(iKeyCode, sPlugin)
                ForcePageReset()
            endif
            return
        endif
        i += 1
    endwhile
EndEvent

Event OnOptionHighlight(int a_option)
    ; Show a hint for any clickable Mod Keys entry
    int i = 0
    while i < iModKeyCount
        if a_option == iModKeyOptionIDs[i]
            SetInfoText("Click to remove this entry from the Hotkey Conflict Manager registry. The mod itself is not affected.")
            return
        endif
        i += 1
    endwhile
EndEvent

Event OnPlayerLoadGame()
    ; Re-sync settings from global variables on every load
    if glz_HCM_warnings
        HCM_API.SetPopupWarningsEnabled(glz_HCM_warnings.GetValue() as bool)
    endif
    if glz_HCM_debug
        HCM_API.SetDebugModeEnabled(glz_HCM_debug.GetValue() as bool)
    endif
    if glz_HCM_game_warnings
        HCM_API.SetGameConflictWarningsEnabled(glz_HCM_game_warnings.GetValue() as bool)
    endif
EndEvent
